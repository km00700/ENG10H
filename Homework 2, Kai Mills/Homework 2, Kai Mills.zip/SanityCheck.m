%Checks for the ideal solutions to test cases
fminsearch(@z_function, [0,0])
fminsearch(@z2_function, [-4,4])
fminsearch(@z2_function, [4,4])
